/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { 
  MapPin, 
  Mail, 
  Phone, 
  Instagram, 
  Utensils, 
  Music, 
  Camera, 
  Flower2, 
  Video, 
  Car, 
  CalendarHeart,
  Waves
} from 'lucide-react';

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.8, ease: "easeOut" }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const services = [
  {
    icon: <CalendarHeart className="w-6 h-6" />,
    title: "Full Wedding Planning",
    description: "End-to-end management of your wedding journey. From initial concept and timeline creation to on-the-day coordination."
  },
  {
    icon: <Utensils className="w-6 h-6" />,
    title: "Catering & Private Chef",
    description: "Exquisite Mediterranean and international cuisine by acclaimed local chefs. Greek BBQ, seafood feasts, and bespoke tasting experiences."
  },
  {
    icon: <Flower2 className="w-6 h-6" />,
    title: "Floral Design & Decor",
    description: "From romantic arches and table centerpieces to ceremony installations — breathtaking floral arrangements that set the perfect atmosphere."
  },
  {
    icon: <Music className="w-6 h-6" />,
    title: "Sound & DJ",
    description: "Professional DJ services and curated playlists to keep your guests dancing from cocktail hour to the last song."
  },
  {
    icon: <Waves className="w-6 h-6" />,
    title: "Sound System & Lighting",
    description: "State-of-the-art sound reinforcement and atmospheric lighting design — from elegant ambient uplighting to dramatic dance floor effects."
  },
  {
    icon: <Camera className="w-6 h-6" />,
    title: "Photography",
    description: "Talented photographers to capture every candid moment and carefully styled portrait, delivering a stunning visual narrative."
  },
  {
    icon: <Video className="w-6 h-6" />,
    title: "Videography",
    description: "Cinematic wedding films that tell your love story. From highlight reels to full-length documentaries, every emotion is preserved."
  },
  {
    icon: <Car className="w-6 h-6" />,
    title: "Guest Experience",
    description: "Transportation, welcome gifts, spa arrangements, local excursions, and any special requests to make your celebration unforgettable."
  }
];

export default function App() {
  return (
    <div className="min-h-screen bg-cream text-dark font-sans selection:bg-gold selection:text-white">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-cream/80 backdrop-blur-md border-b border-dark/5">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="text-2xl font-serif tracking-wider">V E N U S</div>
          <div className="hidden md:flex space-x-8 text-sm uppercase tracking-widest font-medium text-dark/60">
            <a href="#about" className="hover:text-gold transition-colors">About</a>
            <a href="#venue" className="hover:text-gold transition-colors">The Venue</a>
            <a href="#services" className="hover:text-gold transition-colors">Services</a>
            <a href="#contact" className="hover:text-gold transition-colors">Contact</a>
          </div>
          <a 
            href="mailto:venusinspire@gmail.com"
            className="px-6 py-2 border border-dark/20 rounded-full text-xs uppercase tracking-widest hover:bg-dark hover:text-white transition-all duration-300"
          >
            Inquire
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80" 
            alt="Wedding Arch on Beach" 
            className="w-full h-full object-cover opacity-90"
          />
          <div className="absolute inset-0 bg-black/20" />
        </div>
        
        <div className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <p className="text-sm md:text-base uppercase tracking-[0.3em] mb-6 text-white/90">Wedding Planning Services</p>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif mb-8 leading-tight">
              Villa Merilen
            </h1>
            <p className="text-lg md:text-xl font-light italic opacity-90 mb-12">
              Halkidiki, Greece
            </p>
            <div className="w-24 h-[1px] bg-white/60 mx-auto mb-12" />
            <p className="text-sm uppercase tracking-widest opacity-80">Venus • Events That Inspire</p>
          </motion.div>
        </div>
      </header>

      {/* Intro Section */}
      <section className="py-24 px-6 max-w-3xl mx-auto text-center">
        <motion.div {...fadeIn}>
          <h2 className="text-3xl md:text-4xl font-serif mb-8 text-gold">Congratulations on your engagement!</h2>
          <p className="text-lg leading-relaxed text-dark/70 font-light">
            We are delighted to be your dedicated wedding planning partner at Villa Merilen. 
            From concept to celebration, we take care of every detail so you can focus on 
            what truly matters, each other.
          </p>
        </motion.div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div {...fadeIn} className="order-2 md:order-1">
              <img 
                src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80" 
                alt="Event Planning" 
                className="w-full h-[600px] object-cover rounded-sm"
              />
            </motion.div>
            <motion.div {...fadeIn} className="order-1 md:order-2 space-y-8">
              <div>
                <p className="text-gold uppercase tracking-widest text-xs font-bold mb-4">About Us</p>
                <h2 className="text-4xl md:text-5xl font-serif mb-6">Venus Events</h2>
                <p className="text-dark/70 leading-relaxed mb-6">
                  Venus is a boutique event production company specializing in weddings, corporate events, 
                  and retreats. We believe that every event tells a 
                  story, your story, and we are passionate about bringing it to life with creativity, 
                  precision, and heart.
                </p>
                <p className="text-dark/70 leading-relaxed">
                  Our team combines attentive listening with top-tier production expertise. We guide you 
                  through the entire creative process, from the very first spark of inspiration to the 
                  final dance of the evening.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Venue Section */}
      <section id="venue" className="py-24 bg-cream">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div {...fadeIn} className="space-y-8">
              <div>
                <p className="text-gold uppercase tracking-widest text-xs font-bold mb-4">Your Venue</p>
                <h2 className="text-4xl md:text-5xl font-serif mb-6">Villa Merilen</h2>
                <p className="text-dark/70 leading-relaxed mb-6">
                  Nestled along the pristine coastline of Develiki in Halkidiki, Villa Merilen is a private 
                  seafront sanctuary set across 3,000 square meters of lush gardens. Fully renovated in 2024, 
                  this exquisite property accommodates up to 24 guests.
                </p>
                <p className="text-dark/70 leading-relaxed">
                  Featuring an infinity pool, shaded cabanas, a fully equipped outdoor kitchen, and direct 
                  sea access, it is the perfect canvas for your dream wedding.
                </p>
                <a 
                  href="https://www.villamerilen.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-block mt-6 text-xs uppercase tracking-widest border-b border-dark/30 pb-1 hover:border-gold hover:text-gold transition-colors"
                >
                  Visit Villa Website
                </a>
              </div>
            </motion.div>
            <motion.div {...fadeIn}>
              <img 
                src="/PoolandBar-18-1.jpg" 
                alt="Villa Merilen Pool" 
                className="w-full h-[600px] object-cover rounded-sm"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-dark text-cream text-center">
        <div className="max-w-4xl mx-auto px-6">
          <motion.div {...fadeIn}>
            <h2 className="text-3xl md:text-4xl font-serif mb-8">How It Works</h2>
            <p className="text-lg leading-relaxed font-light opacity-80">
              Once you have booked Villa Merilen for your wedding celebration, Venus becomes your dedicated 
              wedding planner. We will work closely with you to design, plan, and produce every element of 
              your special day, from catering and entertainment to florals and photography. Consider us 
              your single point of contact for a seamless, stress-free experience.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20">
            <p className="text-gold uppercase tracking-widest text-xs font-bold mb-4">Curated For You</p>
            <h2 className="text-4xl md:text-5xl font-serif mb-6">Our Services</h2>
            <p className="max-w-2xl mx-auto text-dark/60">
              We provide a full suite of wedding services, carefully curated to create a celebration that is uniquely yours.
            </p>
          </div>

          <motion.div 
            variants={staggerContainer}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {services.map((service, index) => (
              <motion.div 
                key={index}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  show: { opacity: 1, y: 0 }
                }}
                className="p-8 bg-cream hover:bg-white hover:shadow-xl transition-all duration-300 group"
              >
                <div className="text-gold mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <h3 className="text-xl font-serif mb-4">{service.title}</h3>
                <p className="text-sm leading-relaxed text-dark/60">
                  {service.description}
                </p>
              </motion.div>
            ))}
          </motion.div>
          
          <div className="text-center mt-16">
            <p className="italic text-dark/50 font-serif text-lg">
              "Every wedding is unique. If there is something special you envision that is not listed above, please don't hesitate to ask."
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-cream border-t border-dark/5">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <motion.div {...fadeIn}>
            <p className="text-gold uppercase tracking-widest text-xs font-bold mb-4">Let's Create</p>
            <h2 className="text-5xl md:text-6xl font-serif mb-8">Your Perfect Day</h2>
            <p className="text-lg text-dark/70 mb-12 max-w-2xl mx-auto">
              We would love to hear about your vision for your wedding at Villa Merilen. 
              Whether you already have a detailed plan or are just starting to dream, 
              we are here to guide you every step of the way.
            </p>

            <div className="bg-white p-12 shadow-sm max-w-lg mx-auto border border-dark/5">
              <h3 className="text-2xl font-serif mb-8 uppercase tracking-widest">Contact</h3>
              
              <div className="space-y-6">
                <div>
                  <p className="font-bold text-lg">Maayan</p>
                  <p className="text-sm text-dark/50 uppercase tracking-wider">Wedding Planner & Producer</p>
                </div>
                
                <div className="w-12 h-[1px] bg-gold mx-auto" />
                
                <a href="mailto:venusinspire@gmail.com" className="flex items-center justify-center gap-3 text-dark/80 hover:text-gold transition-colors">
                  <Mail className="w-4 h-4" />
                  <span>venusinspire@gmail.com</span>
                </a>
                
                <a href="tel:+306973305514" className="flex items-center justify-center gap-3 text-dark/80 hover:text-gold transition-colors">
                  <Phone className="w-4 h-4" />
                  <span>+30 697 330 5514</span>
                </a>
                
                <a href="https://www.instagram.com/venus.event.production/" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-3 text-dark/80 hover:text-gold transition-colors">
                  <Instagram className="w-4 h-4" />
                  <span>@venus.event.production</span>
                </a>
              </div>
            </div>
            
            <div className="mt-16">
              <div className="text-3xl font-serif tracking-widest text-gold">V E N U S</div>
              <p className="text-xs uppercase tracking-widest mt-2 opacity-50">Events That Inspire</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dark text-white/40 py-8 text-center text-xs uppercase tracking-widest">
        <p>&copy; {new Date().getFullYear()} Venus Events. All rights reserved.</p>
      </footer>
    </div>
  );
}

